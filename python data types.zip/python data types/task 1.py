'''Numeric Types
Create two variables, one integer and one float.
Print their values and types.
Add them together and check the type of result.'''
a=10
b=20.5
print(a,type(a))
print(b,type(b))
add=a+b
print(add,type(add))
