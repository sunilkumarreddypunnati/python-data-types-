'''String to Integer
Take a string "100".
Convert it to integer and add 50.
Print result and its type.'''
a="100"
b=int(a)+50
print(b,type(b))