'''Float Conversion
Take a float number 12.75.
Convert it into:
Integer
String
Print all results with types.'''
a=12.75
b=int(a)
c=str(a)
print(b,type(b))
print(c,type(c))