'''Boolean Conversion
Convert True into: integer, float, string.
Convert False into: integer, float, string.'''
a=True
b=False
print(int(a),float(a),str(a))
print(int(b),float(b),str(b))
