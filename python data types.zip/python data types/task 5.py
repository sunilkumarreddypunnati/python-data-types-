'''String Numbers
Create two strings: "20" and "30".
First concatenate them.
Then convert them into integers and add.
Print both results.
'''
a="20"
b="30"
print("concatenation:",a+b)
add =int(a)+int(b)
print("addition:",add)
