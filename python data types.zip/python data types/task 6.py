'''Check Numeric
Take a string input from the user.
Check if it contains only numbers using .isdigit().
Print True if numeric, otherwise False.
'''
a=input("enter string value:1")
print("Is numeric?", a.isdigit())
