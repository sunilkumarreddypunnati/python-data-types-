'''String to Float → Int
Take string "37.5".
Convert it into float.
Then convert that float into int.
Print all values with types.'''
a="37.5"
b=float(a)
c=int(b)
print(b,type(b),c,type(c))
